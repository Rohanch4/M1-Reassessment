package task.execption;

public class InvalidFoodRegionException extends InvalidFoodDetailsException{
	
	InvalidFoodRegionException(String msg){
		
		super(msg);
	}

}
