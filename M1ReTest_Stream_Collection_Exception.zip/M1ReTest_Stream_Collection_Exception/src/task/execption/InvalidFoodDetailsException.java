package task.execption;

public class InvalidFoodDetailsException extends Exception{
	
	InvalidFoodDetailsException(String str){
		
		super(str);
	}
	

}
