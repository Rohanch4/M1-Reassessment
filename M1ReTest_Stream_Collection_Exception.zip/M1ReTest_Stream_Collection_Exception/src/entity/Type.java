package entity;

public enum Type{
	VEG,
	NON_VEG;
}